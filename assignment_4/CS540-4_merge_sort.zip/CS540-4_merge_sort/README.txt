<How to compile code>

Compile : g++ -std=c++11 main3.cpp -o main3.out

Run : main3.out