<How to compile code>

Compile : g++ -std=c++11 main4.cpp -o main4.out

Run : main4.out